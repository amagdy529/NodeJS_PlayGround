# Qwitter Bot

Qwitter bot was made as an example in this tutorial:
[How to make a twitter bot with node.js](https://beautifuldingbats.com/how-to-make-a-twitter-bot)

Let me know if you have any ideas for improving it.

